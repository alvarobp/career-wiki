# best-practices
A collection of rules and recommendations agreed upon within the organization, either partially or universally.

> **Start here:** [Operations Index](operations/INDEX.md) — single entry point for all documents.
> **Key terms:** [Glossary](operations/glossary.md) — canonical definitions used across all docs.

## Operations

### Core Standards
- [Alerting & On-Call](operations/Alerts-rules.md)
- [Alert Retrospectives](operations/AlertsRetros.md)
- [Deployments & Feature Flags](operations/Deployment-and-Feature-Flags-rules.md)
- [Rollback Operations](operations/Rollback-Operations.md)
- [Observability (Logs, Traces & Metrics)](operations/Observability.md)
- [Runtime Operations](operations/RuntimeOperations.md)
- [Operational Documentation (Best Practices, Playbooks, Runbooks)](operations/Documentation-for-operations.md)

### Incident Management
- [Postmortems](operations/Incidents/Postmortems.md)
