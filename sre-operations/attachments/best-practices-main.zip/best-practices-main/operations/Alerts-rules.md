# Golden Rules: Alerting & On-Call

**Goal:** Detect real problems early without burning out engineers.  
**Audience:** Engineers of all levels.

> These are rules of thumb, not laws. Consider a top-level `Best-Practice-Rules.md` that links this and other child documents to avoid repetition.

---

## Core principle (read first)

**Alerts are a tax on human attention.**  
Every alert:

- Interrupts someone
- Breaks focus
- Increases stress

Treat alerts as expensive; dashboards and observability are cheap. Alert only when the benefit greatly outweighs the cost.

### Observability vs Alerting

- **Observability**: understand systems, trends, and behavior.
- **Alerting**: interrupt humans when immediate action is required.

If an alert does not require immediate external action, it should **not page**.  
High-severity paging is for incidents a sleep-deprived engineer can reasonably act on (e.g., at 3am).  
Low-severity alerts or notifications may exist for business-hours work (capacity planning, early signals), but they should not wake anyone.


### On-call should be predictable and low-stress.

**Healthy on-call**

- Few pages
- Clear runbooks
- Fast resolution
- Long quiet periods
---

## Rules

### Rule 1 — Alert on user-impacting symptoms (prefer Service Level Objectives (SLOs))

- Alert on **user-visible impact** (failed requests, data loss risk, security incidents, hard failures).
- Avoid paging on raw infrastructure causes unless they clearly map to user impact.
- Prefer expressing alerts using **Service Level Objectives (SLOs)**.

**Service Level Objectives-based alert hierarchy**

| Severity | Condition | Action |
|---|---|---|
| **SEV-0 / SEV-1** | Fast burn risking immediate outage | Page immediately (any hour) |
| **SEV-2** | Breached SLO or sustained burn | Page in business hours |
| **SEV-3 / SEV-4** | Approaching SLO violation | Ticket / investigate in business hours |

> Canonical severity definitions: [Postmortems.md](Incidents/Postmortems.md) and [Glossary](glossary.md).

**Rule of thumb**
> Alert when you risk violating your SLO, not when metrics wiggle.

---

### Rule 2 — Every alert must be actionable and self-contained

Every alert should contain:

- **What is broken**
- **How bad it is** (severity, scope, impact)
- **What to do first**

Also define (or ensure the system enforces):

- Owner team
- Severity level
- Runbook or mitigation steps
- Escalation criteria

If any of these are missing, the alert is incomplete and should not page.

**Good**

- `SEV2 — Checkout error rate > 5% for 5m (20% users). First action: rollback release_checkout_v3. Owner: Payments. Runbook: <link>.`

**Anti-patterns**

- “Error rate increased”
- “Look at dashboards”

---

### Rule 3 — Use burn rate, not static thresholds

Static thresholds page too much or too late.  
Burn-rate alerts catch fast incidents and ignore slow, harmless degradation.

**Examples**

- Page if 2-hour burn rate > 14×
- Ticket if 24-hour burn rate > 3×

**Rule**
> Fast burn = page. Slow burn = ticket.

(Keep detailed explanations in a linked “why” document or blog post.)

---

### Rule 4 — Page only on sustained, actionable problems

- Always add a time window.
- Require sustained failure.

**Good**

- `Error rate > 5% for 5 minutes`

**Bad**

- `Error rate > 5% for 10 seconds`

**Rule of thumb**
> If waiting 5 minutes makes it worse, page. Otherwise, don’t.

Low-severity alerts are acceptable only if they consistently lead to action; otherwise tune or delete them.

---

### Rule 5 — One service, one page

Avoid alert storms.

**Do**

- Aggregate signals per service
- Page once with full context

**Avoid**

- One alert per pod
- One alert per region
- One alert per dependency

**Rule**
> One incident = one page.

---


### Rule 6 — Post-incident tuning (separate process doc)

Review alerts after incidents or false pages.  
This is a process topic it self check in (`AlertsRetros.md`).

Suggested retro questions:

- Was the alert useful?
- Did it fire too late or too often?
- Did it page the right people?
- Action: tune, downgrade, or delete

Celebrate deleted alerts 🎉.

---

### Rule 7 — Never Alert on High Cardinality

Alerts require stability. High-cardinality dimensions produce unstable, noisy alerts.

> **If you want alerts, use low-cardinality dimensions.**

**Dimension reference**

| Dimension | Cardinality | Suitable for alerts? |
|---|---|---|
| `service` | Low (tens) | ✅ Yes |
| `endpoint` | Low–medium (hundreds max) | ✅ Yes |
| `region` | Low (single digits) | ✅ Yes |
| `tier` / `plan` | Low (fixed set) | ✅ Yes |
| `provider` | Low (fixed set) | ✅ Yes |
| `user.id` | High (millions, unbounded) | ❌ No |
| `request.id` | High (unbounded) | ❌ No |
| `trace.id` | High (unbounded) | ❌ No |

**How to decide:** A dimension is safe for alerting if its set of possible values is small, fixed, and does not grow with traffic or user count. If the value comes from a request or a user, it belongs in logs or traces — not alerts.

**Rule of thumb**
> Alerts belong to metrics, not logs or traces. Metrics must use low-cardinality dimensions.

---

### Rule 8 — Fewer alerts is a success metric

**Caveat:** This rule only applies as long as **Rule 1 is not violated**.

We intentionally prefer creating pain for ourselves over risking customer harm.
Our top priority is being aware of **any customer-impacting issue before our customers are**.

As long as we reliably detect user impact early, fewer alerts is preferable.
If reducing alerts means learning about issues from customers, we have gone too far.

Track (in retros or dashboards):

- Pages per week
- Pages per service
- Pages per engineer

**Goal**

- Very few pages
- High signal
- High trust

**Rule**
> Silence is success.
