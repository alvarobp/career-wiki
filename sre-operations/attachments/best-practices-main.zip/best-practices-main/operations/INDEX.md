# Operations — Index

A single entry point for all operational standards, processes, and reference material.

> For key terms and definitions used across all documents, see [Glossary](glossary.md).

---

## Core Standards (Best Practices)

Rules and expectations that apply across all services and teams.

| Document | What it covers |
|---|---|
| [Alerting & On-Call](Alerts-rules.md) | How to write alerts, SLO-based alerting, burn rates, on-call health |
| [Alert Retrospectives](AlertsRetros.md) | When and how to review alert quality; cadence, outcomes, ownership |
| [Deployments & Feature Flags](Deployment-and-Feature-Flags-rules.md) | Rolling updates, canary, Blue/Green, expand/contract, flag lifecycle |
| [Rollback Operations](Rollback-Operations.md) | Rollback patterns for stateful systems, expand/shadow/contract, fix-forward |
| [Observability](Observability.md) | Logs vs traces vs metrics, cardinality, sampling, business events, log levels |
| [Runtime Operations](RuntimeOperations.md) | Safe production mutations, blast radius, audit trails, PII, access controls |
| [Operational Documentation](Documentation-for-operations.md) | How to write best practices, playbooks, and runbooks |

---

## Incident Management

| Document | What it covers |
|---|---|
| [Postmortems](Incidents/Postmortems.md) | Severity rubric, when to write, Lite vs Full, blameless culture, action items |

> **Gap (in progress):** Active incident management process (declare → triage → communicate → mitigate → resolve) is not yet documented. See [Postmortems.md](Incidents/Postmortems.md) for the severity rubric and post-incident process.

---

## Reference

| Document | What it covers |
|---|---|
| [Glossary](glossary.md) | Canonical definitions: SLO/SLA/SLI, severity levels, signal types, deployment strategies, feature flag types |

---

## Canonical Severity Scale

One scale, used everywhere. Defined in full in [Postmortems.md](Incidents/Postmortems.md).

| Severity | Summary | Alert action |
|---|---|---|
| **SEV-0** | Broad outage, data loss risk, existential business risk | Page immediately |
| **SEV-1** | Major customer impact, SLO breach, large customer affected | Page immediately |
| **SEV-2** | Significant but limited scope (<10% users, workaround exists) | Page in business hours |
| **SEV-3** | Limited impact, small subset of customers | Ticket / investigate in business hours |
| **SEV-4** | No customer impact, near miss | Ticket (optional) |

> For fintech/web3: funds at risk with no recovery path → SEV-0. Key material compromise → SEV-0. See [Postmortems.md](Incidents/Postmortems.md) for full criteria.

---

## Schema Migration Canonical Pattern

One pattern, one name. Defined in full in [Rollback-Operations.md](Rollback-Operations.md).

```
Phase 1 — Expand         Add nullable columns/tables. Old code unchanged.
Phase 2 — Shadow         Dual writes (old + new). Shadow reads from new to verify parity. Backfill historical data.
Phase 3 — Reverse Shadow Switch primary reads to new schema. Continue writing to old as safety net.
Phase 4 — Contract       Stop dual writes. Drop old schema only after monitoring confirms no references.
```

> "The Contract phase is where rollbacks die. Delay it."

---

## Planned / Missing Documents

The following are known gaps not yet documented:

- **Incident Management** — active incident lifecycle (declare, roles, comms, escalation, handoff)
- **On-Call Guide** — rotation, handoff, health metrics, break-glass access
- **SLO / Error Budget Framework** — how to define SLOs, measure burn rate, handle budget exhaustion
- **Web3 / Blockchain Operations** — stuck transactions, key rotation, smart contract operations, chain RPC failover
- **External Communication Templates** — customer-facing incident comms, regulatory notification timelines
- **Compliance Mapping** — SOC 2 / PCI-DSS control mapping for all operational practices
