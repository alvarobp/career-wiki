# Glossary

Canonical definitions for terms used across all operational documents.
When a term appears in a best practice, playbook, or runbook, this is what it means.

---

## Observability Signals

**Log**
A discrete, immutable event. Something happened at a specific moment with full context.
Logs answer *"what exactly happened?"* and are the source of truth for auditing and compliance.
Logs must **not be sampled** for audit or security use cases.

**Span**
A unit of work over time with a start, end, and optional parent/child relationships.
Spans answer *"how did this flow execute and how long did each step take?"*
A **Trace** is the full tree of spans for one request or operation.
Sampling is normal for traces.

**Metric**
A numeric aggregation over time: rates, percentiles, counts, error budgets.
Metrics answer *"is this system healthy right now?"* and drive alerts.
Never use high-cardinality dimensions (user.id, request.id) in metrics.

**The Prime Directive**
> If it has duration and causality → **span**.
> If it has meaning on its own → **log**.
> If it judges health over time → **metric**.

**Cardinality**
The number of distinct values a dimension can take.
- **Low cardinality**: `http.method`, `status`, `region` → safe in metrics and alerts.
- **High cardinality**: `user.id`, `order.id`, `transaction_hash` → safe in spans/logs only.

High cardinality in metrics causes cost explosions and alert storms.

**Business Event**
A log that represents what the company definitively did (payment completed, NFT minted, transfer failed).
Business events are durable, stable, unsampled, and retained for years.
They are not debug logs — they are records of truth consumed by finance, compliance, and auditors.

**Tail Sampling**
A sampling strategy that decides whether to keep a trace *after* it completes.
Allows keeping 100% of error traces and anomalous transactions while sampling routine traces.
Required for critical paths in fintech systems.

---

## Service Level Terminology

**SLI — Service Level Indicator**
The actual measurement. E.g., the fraction of HTTP requests that return a 2xx response within 300ms.

**SLO — Service Level Objective**
The internal target for an SLI. E.g., "99.9% of requests succeed within 300ms over a 30-day window."
SLOs are internal and operational.

**SLA — Service Level Agreement**
A contractual commitment to customers or partners. Always more lenient than the SLO.
E.g., SLO = 99.9%, SLA = 99.5%. The gap is your margin of safety.

**Error Budget**
The allowed failure budget derived from the SLO.
E.g., 99.9% SLO over 30 days = 43.8 minutes of allowed downtime.
When the error budget is exhausted, reliability must take priority over new features.

**Burn Rate**
How fast you are consuming your error budget relative to the SLO window.
- Burn rate 1× = consuming budget exactly in line with the window.
- Burn rate 14× = consuming the 30-day budget in ~2 hours.

> Fast burn (>14× over 2h) → page immediately.
> Slow burn (>3× over 24h) → ticket / investigate.

Burn-rate examples assume a **30-day SLO window**. Recalculate if your window differs.

---

## Severity Levels

One canonical scale. Source of truth: [Postmortems.md](Incidents/Postmortems.md).

| Level | Summary | Examples |
|---|---|---|
| **SEV-0** | Broad outage, existential business risk | Full platform down, funds at risk with no recovery path, key material compromise, on-chain state corruption |
| **SEV-1** | Major customer impact, SLO breach | Large customer affected, payment processing degraded, clear SLO violation |
| **SEV-2** | Significant but limited scope | <10% users affected, workaround exists, single non-critical service down |
| **SEV-3** | Limited impact, low urgency | Small subset of customers, minimal degradation |
| **SEV-4** | No customer impact or near miss | Internal-only issue, caught before production impact |

> Duration amplifies severity: a SEV-3 lasting >4 hours may warrant SEV-2 treatment.
> Financial transaction impact or regulatory exposure → escalate to SEV-1 minimum.
> Funds at risk with no recovery path → SEV-0.

---

## Deployment Strategies

**Rolling Update**
Replace instances incrementally. Default for most changes.
Simple, cheap, zero downtime. New and old versions run simultaneously during rollout.

**Canary**
Route a small percentage of traffic to the new version (5% → 25% → 100%).
Only use when you can measure error rate and latency between steps.
Stop the rollout if any signal degrades beyond defined thresholds.

**Blue/Green**
Two full environments (blue = live, green = new). Switch traffic instantly.
Powerful for instant rollback but expensive and dangerous with databases.
**Do not use Blue/Green when rollback can cause data loss.**

**Expand / Shadow / Reverse Shadow / Contract**
The canonical pattern for schema migrations. Never do a schema migration without it.

| Phase | What happens |
|---|---|
| **Expand** | Add new nullable columns/tables. Old code continues to work. |
| **Shadow** | Write to both old and new schemas. Read from old (source of truth). Compare new schema reads in background. Backfill historical data. |
| **Reverse Shadow** | Switch primary reads to new schema. Continue writing to old as safety net. Monitor for parity errors. |
| **Contract** | Remove dual writes and old schema. **Delay this phase.** This is where rollbacks die. |

> Full description in [Rollback-Operations.md](Rollback-Operations.md).

---

## Feature Flags

**Types and expected lifetimes**

| Prefix | Type | Lifetime | Purpose |
|---|---|---|---|
| `release_` | Release | Days–weeks | Ship incomplete or risky changes safely |
| `exp_` | Experiment | Short–medium | A/B tests, data learning |
| `ops_` | Operational | Medium–long | Circuit breakers, safety switches |
| `perm_` | Permission | Long-lived | Paid features, entitlements |

**Kill Switch**
An `ops_` flag that disables a feature immediately without a deploy.
Every high-risk feature should have one. The OFF state must be tested.

**Circuit Breaker**
An automatic or manual switch that stops calls to a failing dependency.
Lives in service code (exception to "check flags at entry points" rule).

---

## Incident Roles

**IC — Incident Commander**
Single owner of decisions, coordination, and communications during an incident.
The IC does not need to be the one fixing the problem — their job is to coordinate.
At small team sizes, the IC may also own mitigation.

**DRI — Directly Responsible Individual**
The single accountable person for a decision or outcome.
During incidents, the IC is the DRI for the incident overall.
Action items in postmortems must each have one DRI (not "the team").

**Ops Lead**
At larger team sizes, the IC can delegate a dedicated Ops Lead to own technical mitigation so coordination does not stop.

---

## Incident Documents

**Postmortem**
A structured learning document written after an incident.
Not a blame document — a system improvement document.

| Type | When | Time |
|---|---|---|
| **Full** | SEV-0, SEV-1 (mandatory); SEV-2 (recommended) | 1–3 pages, sync review |
| **Lite** | SEV-2, SEV-3, SEV-4 (optional) | 10–15 min, async |

**MTTI — Mean Time to Identify**
Average time from when an incident started to when it was detected.
Reduced by better alerting, SLOs, and observability.

**MTTR — Mean Time to Recover**
Average time from incident detection to full resolution.
Reduced by better runbooks, automation, and rollback tooling.

---

## Operational Documents

**Best Practice**
What "good" looks like. Defines standards and expectations.
*"What is the correct way we do X?"*

**Playbook**
How to run a scenario. Covers roles, decisions, and communication.
*"What do we do when X happens?"*

**Runbook**
Step-by-step technical guide for one specific task. Must be safe to follow blindly.
*"How do I do X right now?"*

> A playbook without roles is a blog post.
> A runbook without validation steps is a guess.

---

## Security and Access

**Blast Radius**
The scope of impact if an operation goes wrong. Always expose blast radius before executing mutations in production.

**Break-Glass**
Emergency escalation procedure for accessing systems or executing operations beyond normal authorization.
Must be: justified, approved, time-bounded, logged, and reviewed post-incident.

**Least Privilege**
Grant only the minimum access required to perform a specific task.
Read access by default. Write access requires explicit elevation and justification.

**PII / PHI**
Personally Identifiable Information / Protected Health Information.
Never query, log, or expose without explicit justification, authorization, and time-bound access.

**Audit Trail**
A complete, immutable record of who did what, when, and why in production.
Required for all production mutations. Must be stored in an append-only system with minimum 1-year retention.

---

## Fintech / Web3 Specific

**Irreversible Operation**
Any operation whose effects cannot be undone: blockchain transactions, on-chain mints, outbound payments, ledger entries.
Code rollback does NOT undo irreversible operations.
Design for idempotency and reconciliation, not rollback.

**Financial Reconciliation**
The process of verifying that internal records match external system state (blockchain state, payment processor records, bank statements).
Reconciliation failures must trigger alerts and postmortems.

**Hot Wallet**
A wallet with private keys accessible to the application for signing transactions.
Access to signing operations must be auditable, tool-driven, and never ad-hoc.

**Chain Confirmation**
A blockchain transaction is not final at submission — it becomes final only after sufficient block confirmations.
"Transaction submitted" ≠ "Transaction succeeded."
Observability must distinguish submission, confirmation, and finality.
