# Golden Rules: Operating Into the Runtime

**Goal:**
Give engineers the right tools to operate production safely, audibly, and repeatably — without relying on heroics, tribal knowledge, or wide-open access.

**The safest production system is one that does not require heroics.**
If operating production requires bravery, the system needs better tooling — not braver engineers.

**Audience:**
Engineers, SREs, and anyone with production access.

---

## Core Principle (Read First)

**Engineers should not rely on direct, unguarded production access to get things done.**

Unstructured direct access is:

- Hard to audit
- Easy to misuse under stress
- Error-prone without validation
- Risky for customer data (PII / PHI)
- Difficult to review or roll back

The goal is not to lock engineers out — it is to **build operational tools that encode best practices**, expose blast radius, and allow engineers to confidently do the right thing.

Production changes should be **tool-driven, reviewed, and traceable**.

---

## A Note on Speed (Especially During On-Call)

During incidents, it is natural to feel that **code-driven operations are slower** and that an **interactive console is faster**.

This feeling is misleading.

- Interactive consoles feel fast because they remove friction.
- Code-driven workflows feel slower because they force thinking.

In practice:

- Console-driven actions increase error rates.
- Mistakes compound quickly under stress.
- There is no review, no validation, and often no rollback.

The real solution is **operational tools** — tools that encode the right steps, expose blast radius before you act, and help you apply best practices even under pressure.

For example: a backfill tool that runs against 1 row first, shows you what will change, forces explicit validation, then divides work into safe batches. This is faster than a raw console because it prevents the costly mistakes that raw access enables.

**Speed without confidence is not speed.**

The goal during on-call is not to act quickly —
it is to act **correctly** under pressure.

If an operation feels urgent but cannot be executed safely, that is a signal that the system is missing the right tooling.

Fix the system, not the process.

**Rule of thumb**
> The console feels faster. The right tool is faster in the long run.

---

## Rule 1 — Prefer Operational Tools Over Wide-Open Consoles

Any operation that mutates production state should be performed via:

- Internal operational tools (backoffice UIs, admin scripts with guardrails)
- Reviewed scripts or automated jobs
- Predefined runbooks

**"Console" here means a wide-open shell or database console** — not internal backoffice tooling.
Internal consoles that encode validation, blast-radius checks, and audit trails are exactly what we want to build toward.

Avoid:

- Ad-hoc commands in wide-open production shells or DB clients
- Manual database mutations outside of controlled tooling
- "Just this once" fixes with no review or audit trail

**Rule of thumb**
> If it can be done twice, it should be a tool.

---

## Rule 2 — Mutations Must Go Through Tools That Expose Blast Radius

Direct runtime or database access is acceptable for:

- Debugging
- Inspection
- Verification
- Incident triage

When **mutation is required** (data fix, backfill, reconciliation, hotfix), engineers should not be stopped — but the operation must go through a path that:

- Makes the blast radius visible before execution
- Encodes validation steps (e.g. dry-run, single-row test)
- Produces an audit trail
- Is reviewable after the fact

If no such tool exists yet, use a runbook or script (see Rule 5) as a temporary bridge — and flag that a tool should be built.

The point is not to prevent engineers from fixing production.
The point is to make sure the *how* is protected.

---

## Rule 3 — Every Production Operation Must Be Auditable

All production actions must leave a **clear audit trail**:

- Who executed it
- When it ran
- What it changed
- Why it was executed

Manual console actions without logs, approvals, or artifacts are unacceptable in regulated environments (SOC 2, PCI).

If it cannot be audited, it should not exist.

---

## Rule 4 — No Unfiltered Access to PII / PHI

Engineers and SREs should not casually view customer data.

Requirements:

- Queries must explicitly filter or redact PII / PHI
- Access should be minimized to what is strictly necessary
- Logs, outputs, and screenshots must never contain raw sensitive data

If sensitive data must be accessed, it must be:

- Justified
- Logged
- Time-bounded
- Reviewed

---

## Rule 5 — Use Predefined Runbooks for Risky Operations (Then Build Tools)

High-risk operations must have **pre-created runbooks**, including:

- Backfills
- Data reconciliation
- One-off fixes
- Large queries
- Runtime variable inspection
- Memory or leak investigations

Runbooks should define:

- Preconditions
- Exact commands or scripts
- Validation steps
- Rollback strategy

Runbooks reduce fear, errors, and decision fatigue during incidents.

**Runbooks are a stepping stone, not the destination.**
Once a runbook is used more than once, it should be pulled into an operational tool that enforces those steps automatically.

---

## Rule 6 — Prefer Blast Radius Exposure Over Access Lockdown

Restricting access is not the primary safety lever — **making blast radius visible is**.

When designing access controls or operational tools, prioritize:

- Showing the engineer what will be affected before they act
- Batching risky operations into smaller, verifiable steps
- Requiring explicit confirmation for high-impact actions

For production access:

- Prefer temporary access tied to a specific task or incident (e.g. on-call window)
- Remove access automatically when no longer needed
- Long-lived admin access should be rare and explicitly justified

But do not let access controls become the excuse for missing tooling.
The goal is engineers who can act confidently — not engineers who are afraid to act.

---

## Rule 7 — Design Systems That Enable Good Decisions, Not Just Prevent Bad Ones

Systems must be designed assuming:

- Mistakes will happen
- Humans will act under stress
- Credentials can be misused

Rather than focusing only on prevention, build tools that:

- Expose blast radius so owners can make informed decisions
- Surface the right guardrails at the right moment
- Make the safe path the easy path

Controls that block without context tend to frustrate engineers and make their minds shut off.
Controls that inform and guide build better ownership.

The specific outcomes to protect:

- Silent data mutation
- Ledger corruption
- Untraceable financial changes

Security is not about trust — it is about guardrails that enable good judgment.

---

## Rule 8 — If It's Scary, It's a Smell (Reduce Fear Across Engineering)

Fear is a signal.

If an operation:

- Feels dangerous
- Requires "being careful"
- Depends on tribal knowledge
- Cannot be reviewed beforehand

Then the system is incomplete.

Turn fear into code, automation, and documentation.

This applies beyond on-call. Reducing operational fear is an **engineering-wide goal** — from deployment to data access to incident response. Every time we eliminate a scary process, we make the whole team safer and faster.

---

## Rule of Thumb Summary

- **Build tools that expose blast radius, not just walls that block**
- **Observe manually, mutate via tools with guardrails**
- **No audit trail = no production action**
- **No PII by default**
- **Runbooks before emergencies → tools before the next incident**
- **Temporary access over permanent power**
- **If it's scary, build the tool that makes it safe**

---
