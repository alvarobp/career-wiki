# Alert Retrospectives (AlertsRetros)

**Purpose:**  
Continuously reduce alert noise while increasing signal quality and trust.

This document defines **when, how, and how often** alerts are reviewed.  
It intentionally lives **outside** the alerting rules themselves.

---

## Cadence (This Is Not Optional)

Alert retrospectives must run on a **fixed cadence**.

The cadence is a function of **alert volume and pain**, not preference.

If alerts are frequent, reviews must be frequent.

### Recommended Cadence

- **High alert volume / noisy systems**
  - **Monthly** (or more often)
- **Moderate alert volume**
  - **Quarterly**
- **Low alert volume / stable systems**
  - **Bi-yearly**

Teams may choose a shorter cadence, but should not exceed bi-yearly.

---

## Triggered (Out-of-Band) Retros

Cadence-based retros are **not sufficient** on their own.

Run an immediate alert retro after any of the following:

- A SEV1 or SEV2 incident
- A false page
- Repeated alerts that were ignored
- Any page that caused confusion or delayed response

Do not wait for the next scheduled retro if alert quality is clearly poor.

---

## Scope of an Alert Retro

Alert retros focus only on **alert quality**, not on root cause analysis of the incident.

This document answers:
- *Was the alert useful?*
- *Did it page the right people at the right time?*

It does **not** answer:
- *Why did the system fail?*
- *Who caused the issue?*

---

## Core Questions (Required)

For each alert involved, answer:

1. **Was the alert actionable?**
   - Did it clearly state what was broken?
   - Did it indicate severity and user impact?
   - Did it tell the on-call what to do first?

2. **Was the alert timely?**
   - Did it fire too late?
   - Did it fire too early?
   - Did it fire repeatedly for the same incident?

3. **Was paging justified?**
   - Did it require immediate external action?
   - Could it have waited for business hours?
   - Would a sleep-deprived engineer reasonably solve it?

4. **Did it page the right people?**
   - Correct service?
   - Correct owning team?
   - Clear escalation path?

If any answer is “no”, the alert needs to change.

---

## Required Outcomes

Every alert retro must result in **one** of the following actions:

- **Tune** the alert (thresholds, burn rate, time window)
- **Downgrade** severity (page → notification, notification → ticket)
- **Replace** it with a better signal
- **Delete** it

No alert should leave a retro unchanged by default.

---

## Alert Deletion Is a Success

Deleting alerts is not failure.

Deleted alerts mean:
- Less noise
- Higher trust
- Faster response during real incidents

Celebrate deleted alerts.

---

## Metrics to Review (Trend, Not Targets)

Review trends over time:

- Pages per week
- Pages per service
- Pages per engineer
- Percentage of pages that resulted in action

These metrics are signals, not goals.  
Use them to guide discussion, not to assign blame.

---

## Ownership

- Service owners are responsible for updating alerts after retros
- If an alert has no clear owner, it should not exist
- Paging systems may enforce ownership, but retros verify **quality**

---

## Anti-Patterns to Watch For

During retros, explicitly flag these:

- Alerts that say “check dashboards”
- Alerts that fire but no one acts
- Alerts no one understands
- Alerts that page for known, accepted risks
- Alerts that exist “just in case” and never change

These should be tuned down or removed.

---

## Rule of Thumb

> The noisier the system, the shorter the retro cadence.

> If alert reviews feel expensive, alerting is already broken.

---

## Relationship to Alerting Rules

- **Alerting rules** define how alerts *should be written*
- **Alert retros** define how alerts *are corrected over time*

Both are required for a healthy on-call experience.
