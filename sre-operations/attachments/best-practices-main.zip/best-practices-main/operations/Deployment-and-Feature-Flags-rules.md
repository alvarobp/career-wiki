# Golden Rules: Deployments & Feature Flags

Goal: Ship safely, avoid 2am incidents, reduce stress.  
Audience: Engineers of all levels and backgrounds.

These are **rules of thumb**, not laws.  
Default to safety. Optimize later.

---

## A Very Important Principle (Read First)

### Feature flags are **bad engineering** by default

Feature flags:

- Add complexity
- Hide behavior
- Increase cognitive load
- Create long-term maintenance cost

From a pure design perspective, **they make systems worse**.

**We still use them** because they significantly reduce deployment risk and enable
safe, incremental delivery.

So we treat feature flags as:

- Temporary
- Intentional
- Actively managed

> Feature flags are allowed **only if** they have:
>
> - Clear purpose
> - Clear owner
> - Clear expiration
> - Clear observability

If any of these are missing, the flag should **not exist**.

## Quick Safety Checklist

Before deploy:

- Do we have rollback rules?
- Does this touch the database?
- Is the feature behind a flag?
- Are metrics visible?

Review Weekly:

- Remove old flags
- Review long-running canaries
- Check ops flags
- Celebrate deleted flags 🎉

---

### Rule 1 — Use Rolling Updates by default. Upgrade to Canary when you can measure

**Rolling updates** are simple, cheap, and good enough for most changes.

**Canary deployments** are better *when you have monitoring*.

**Do**

- Rolling update for normal changes
- Canary: 5% → 25% → 100%
- Wait and observe between steps

**Do not**

- Deploy everything at once
- Run canary without metrics

**Rule of thumb**
> If you cannot see error rate and latency, do not canary.

---

### Rule 2 — Use Blue/Green only for stateless and high-risk situations

Blue/Green means:

- Two environments (blue + green)
- Instant traffic switch
- Instant rollback

It is **powerful but expensive and complex**.

**Good use cases**

- Third-party API upgrade (stateless)
- Very high-risk deploy (peak traffic days)
- Compliance or regulatory changes

**Bad use cases**

- Normal API changes
- Bug fixes
- “Because we always do Blue/Green”

---

### ⚠️ Critical Warning — Blue/Green + Databases = Rollback problems

If your deployment **writes new data to the database**, Blue/Green rollback can cause data loss.

**What can go wrong**

- New code writes data
- You rollback to old code
- Old code cannot see the new data
- Users think their data is lost

**Golden rule**
> If rollback can lose user data, do NOT use Blue/Green.

---

### Rule 3 — Use Expand / Shadow / Reverse Shadow / Contract for ALL database schema changes

If you care about **zero data loss**, use the canonical pattern. Full description: [Rollback-Operations.md — Rule 2](Rollback-Operations.md).

| Phase | What happens | Can roll back to previous step? |
|---|---|---|
| **Expand** | Add nullable columns/tables. Old code unchanged. | ✅ Yes |
| **Shadow** | Write to old + new. Read from old. Shadow-read new to verify parity. | ✅ Yes |
| **Backfill** | Populate new columns/tables with historical data. Verify parity. | ✅ Yes |
| **Reverse Shadow** | Switch primary reads to new. Continue writing to old as safety net. | ✅ Yes (instant) |
| **Contract** | Stop dual writes first. Verify old schema has zero reads/writes. Drop old schema. | ✅ Before drop / ❌ After drop |

**Rule of thumb**
> Database changes are slow by design. That is the price of safety.
> The Contract phase is irreversible once the schema is dropped — prove no one uses the old schema before proceeding.

---

### Rule 4 — Always define rollback rules before deploying

During incidents, humans panic.

**Before deploy, define**

- Error rate threshold
- Latency threshold
- Timeout
- Auto-rollback yes/no

**Good**

- Automatic rollback
- Notify humans

**Bad**

- “We will rollback manually if needed”

---

## Feature Flags

### Rule 5 — Name flags so humans understand them

Use this pattern:

**Types**

- `release_` → temporary rollout
- `exp_` → experiment / A-B test
- `ops_` → operational safety (circuit breaker)
- `perm_` → paid or permission feature

**Good examples**

- `release_checkout_v3`
- `ops_payment_circuit_breaker`
- `exp_pricing_annual`
- `perm_export_pdf_premium`

**Bad examples**

- `flag1`
- `temp`
- `enable_v2`

#### Flag categories and expected lifetime

Different flags have different lifecycles.
They must be treated differently.

| Type        | Expected lifetime | Purpose |
|-------------|------------------|---------|
| `release_`  | Short (days–weeks) | Ship incomplete or risky changes safely |
| `exp_`      | Short–medium      | Experiments, A/B tests, data learning |
| `ops_`      | Medium–long       | Operational safety, circuit breakers |
| `perm_`     | Long              | Permissions, entitlements, paid features |

**Rule of thumb**
> If a flag outlives its category, something is wrong.
---

### Rule 6 — Check flags at system boundaries

Evaluate flags:

- In controllers
- In request handlers
- At entry points

**Avoid**

- Flag checks inside loops
- Flag checks deep in business logic
- Many flags combined together

**Exception**

- `ops_` flags (circuit breakers) can live in service code

---

### Rule 7 — Every flag is temporary debt

When creating a flag, define:

- Owner
- Creation date
- Expiration date
- Cleanup ticket

**Recommended cleanup**

- `release_`: delete after 30–60 days
- `exp_`: delete after experiment
- `ops_`: review every 3 months
- `perm_`: document clearly

---

### Rule 8 — Flags must be observable

You must know:

- Which flags were ON
- For which users
- When errors happened

**Minimum**

- Log flag state
- Metrics per flag variant
- Alerts per variant

**Rule**
> If you cannot answer “which flags were ON?”, you are blind.

---

### Rule 9 — Flags are NOT configuration

**Flags**

- Choose code path (on / off)

**Config**

- Numbers and strings (timeouts, limits)

If you need numbers, use config — not flags.

---

### Rule 10 — Keep flags binary (on/off)

Multi-variant flags are hard to test and reason about.

If you need variants:

- Use a real experimentation platform
- Or redesign the feature

---

Version: 0.1  
Owner: Engineering  
Review: Quarterly
