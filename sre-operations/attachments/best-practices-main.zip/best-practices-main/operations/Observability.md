# Golden Rules: Observability (Logs, Traces & Metrics)

Goal: Understand production **without lying to yourself**.
Audience: Engineers of all levels.

These are **rules of thumb**, not laws.
Default to clarity. Optimize later.

---

## Key Definitions

Before reading the rules, align on what these terms mean here:

**Log**
A discrete, immutable event: something happened, at a specific moment, with full context.
Logs are the source of truth for auditing, forensics, and compliance — answering *"what exactly happened?"*
Because of this, logs must **not be sampled**, especially for audit or security use cases.

**Span / Trace**
A span represents a unit of work over time — it has a start, an end, and optional parent/child relationships with other spans. A trace is the full tree of spans for one request or operation.
Traces answer *"how did this flow execute and how long did each step take?"*
Sampling is normal and expected for traces: a representative subset is enough to detect trends and failures.
> In Datadog: logs → **Logs**, spans/traces → **APM**.

**Metric**
A numeric aggregation over time: rates, percentiles, error budgets, SLO burn rates.
Metrics answer *"is this system healthy right now?"* and drive alerts.
> Metrics are the alerting layer. Logs and traces explain what happened; metrics decide when to page.

---

## An Uncomfortable Truth (Read First)

### Observability fails when signals are mixed

Most observability pain comes from:
- Logging what should be traced
- Sampling what should be evidence
- Storing data without meaning

**Rule of thumb**
> If you are unsure where something belongs, you are probably putting it in the wrong signal.

---

## The Prime Directive

> **If it has duration and causality, it is a *span*.
> If it has meaning on its own, it is a *log*.
> If it judges health over time, it is a *metric*.**

This rule overrides all others.

---

## Before Instrumenting: Rules

Signals should **not** contain:

- **Time or duration data in logs** — that belongs in spans (`duration_ms` → trace, not log)
- **Sampled audit or compliance records** — sampling logs destroys truth; only traces should be sampled
- **Unmasked PII or confidential data** — assume every log will be leaked, subpoenaed, or audited
- **High-cardinality dimensions in metrics** — `user.id` or `request.id` as metric tags will cause cost explosions and alert storms

> High cardinality = a field with millions of distinct values (e.g., user_id, order_id, transaction_hash).
> This is fine in traces (per-request investigation), dangerous in metrics (they are aggregated into time series).

If a signal violates any of these, stop and rethink before instrumenting.

---

## Rule 1 — Do Not Log Time

Logging time is almost always a mistake.

> **If you feel the urge to log `duration_ms`, you want a span.**

Time-related concepts:
- latency
- start / end
- retries
- timeouts

belong to **tracing**, not logging.

**Rule of thumb**
> Logs describe facts (immutable events at a point in time). Spans describe time (intervals with causal relationships).

---

## Rule 2 — Prefer Logging Known Facts Over Sampling

Sampling is not neutral.

> **Prefer logging known facts when something is definitively bad or wrong — not probabilistic signals.**

Sampling is a smoke test: it tells you the house might be burning, not whether there is a fire.
Logs are for when you need certainty, not confidence intervals.

- Traces → sampling is normal and expected
- Logs → sampling destroys truth; once sampled, a log is no longer a source of fact

### The Sampling Trap (Critical Paths)

In critical systems (fintech, payments, minting, transfers):

> "Sorry, that trace was sampled out" is unacceptable.

Adapt your sampling strategy once a path is identified as elevated risk — do not assume you can perfectly label "critical" paths in advance. Observability is always partially miscalibrated; the right posture is to increase retention when signals indicate risk.

**Do**

- Use tail sampling
  - keep all errors
  - keep all anomalous transactions (unexpected latency, retries, unexpected status)
- Use 100% tracing for confirmed critical paths once identified

**Rule of thumb**
> Sampling is a privilege, not a default. Audit and compliance logs are never sampled.

---

## Rule 3 — Do Not Rebuild Tracing With Logs

Logs that explain flow are traces in denial.

If you rely on logs with:
- `requestId`
- start / end messages
- duration fields

you are rebuilding tracing **without**:
- parent–child relationships
- parallelism
- correct timing
- intelligent sampling

**Rule of thumb**
> If logs need ordering to make sense, you want spans.

---

## Rule 4 — Semantics Beat Structure

Structured data without shared meaning does not scale.

Use a layered approach:

**Infrastructure and protocol concepts** → use OpenTelemetry / Datadog standard semantic attributes:
- `http.request.method`, `http.route`, `http.response.status_code`
- `db.system`, `server.address`
- `rpc.method`, `rpc.service`

> OTel semantic conventions evolve. Always check the latest stable spec at [opentelemetry.io/docs/specs/semconv](https://opentelemetry.io/docs/specs/semconv/). The names above reflect stable conventions as of OTel v1.21+.

**Domain and business concepts** → use your own attributes that reflect your business:
- `payment.status`, `mint.result`, `transfer.type`, `wallet.provider`

**Do not replace standard attributes with custom ones:**
- ❌ `route` instead of `http.route`
- ❌ `status` instead of `http.response.status_code`

Replacing standard attributes breaks default dashboards, alerting templates, and cross-service correlation in tools like Datadog.

---

## Rule 5 — Errors Live Where the Failure Happens

Errors are not all the same.

> **Operational errors belong to spans.
> Business, security, and audit errors belong to logs.**

**Spans** carry operational errors:
- `status = ERROR` + exception for infrastructure or execution failures

**Logs** carry truth:
- compliance failures, security events, business state transitions

Spans and logs serve different audiences: spans go to engineers debugging a flow, logs go to auditors, compliance, and security teams.
Mixing them leads to noisy traces, meaningless logs, and broken alerts.

**Do not** duplicate errors without intent — if you log and span the same error, be explicit about why.

---

## Rule 6 — Cardinality Is a Cost

High cardinality is not free.

> **Cardinality = the number of distinct values a field or dimension can take.**

| Cardinality | Examples | Safe in |
|---|---|---|
| Low | `http.method`, `status`, `region` | Metrics, alerts, spans |
| High | `user.id`, `order.id`, `trace.id`, `transaction_hash` | Spans only |

> **High-cardinality attributes are for investigation (spans/logs), not aggregation (metrics).**

- Traces → tolerate high cardinality (it is expected for per-request investigation)
- Metrics → high-cardinality dimensions explode time series, break dashboards, and increase cost directly (Datadog charges per metric series)
- Logs → storage is cheap; indexing high-cardinality fields is not

**Examples of cardinality explosions to avoid:**
- Using `user.id` as a metric tag → one metric series per user
- Using `request.id` as a metric tag → unbounded, grows with traffic
- Using `transaction_hash` in an alert dimension → alert storm: one alert per transaction

---

## Rule 7 — Tenant IDs Are Sometimes OK, User IDs Rarely Are

Identifiers have consequences.

> **Tenant IDs can be useful if bounded.
> User IDs are usually a mistake.**

**What is a tenant?**
A bounded grouping of users representing a business unit: pricing tier, partner, plan (e.g., gold / silver / enterprise). Typically hundreds or thousands — not millions.

**Do**

- `tenant.id` → hundreds or thousands max → useful for SLO slicing, cost attribution, and alert grouping

**Avoid**

- `user.id` → high cardinality + privacy risk → use for audit/security logs only

Prefer aggregable dimensions for metrics:
- `plan`, `tier`, `region`, `provider`

---

## Rule 8 — Business Events Are First-Class Logs

Not all logs are debug logs.

Separate clearly:

| Type | Audience | Characteristics |
|---|---|---|
| **Application / Operational Logs** | Engineers debugging | Ephemeral, evolve with code, optimized for troubleshooting |
| **Business Events** | Finance, product, BI, compliance, auditors | Durable, stable, unsampled, retained for years |

Business events represent what the company definitively did:
- User minted NFT
- Payment completed
- Transfer failed
- Subscription upgraded

These are not debug signals — they are records of truth, often consumed by finance or compliance months or years later.

**Rule of thumb**
> If it represents money, a state transition, or a security decision, it is a business event — not a debug log.

---

## Rule 9 — Never Log Confidential Information

Assume every log will be:

- leaked
- subpoenaed
- misused

**Never log**

- private keys
- seed phrases
- credit card numbers
- auth tokens
- signed payloads
- raw wallet addresses (unless masked)
- PII or PHI you would not want an engineer or auditor reading without explicit authorization

Prefer:
- hashes
- masked values
- references

**Rule of thumb**
> Security and privacy rules override debugging convenience.

---

## Rule 10 — Good Attributes by Signal

### Spans (low / medium cardinality)

- http.request.method
- http.route
- http.response.status_code
- service.name
- service.version
- db.system
- server.address
- provider
- retry.count
- region
- tenant.id (bounded)

Avoid:
- emails
- tokens
- payloads
- full SQL with data

---

### Logs (event-focused)

- event.type
- actor.id
- resource.id
- message (human-readable)
- trace.id (correlation only)
- user.id (audit/security only)

---

## Rule 11 — Retention Reveals Intent

Storage duration exposes misuse.

> **If you want to keep it for years, it is not a trace.**

- Logs → long retention
- Traces → short retention
- Metrics → aggregated retention

---

## Rule 12 — Do Not Duplicate Without Intent

Duplication is a cost.

**Bad**

- latency in logs and spans
- start/end logs and spans

**Acceptable**

- business log + technical span

---

## Rule 13 — Auto-Instrumentation Is a Bootstrap

Automatic instrumentation is a starting point.

**It**

- gives fast visibility
- helps adoption
- is noisy and expensive at scale

**Mature approach**

1. Enable auto-instrumentation
2. Observe cost and noise
3. Identify critical paths
4. Remove useless spans
5. Add manual spans with intent

> **Automatic spans show activity.
> Manual spans show meaning.**

---

# Log Levels — Golden Rules

## L0 — Levels Are a Budget

> **A log level is not emotion. It is cost.**

---

## L1 — TRACE Is a Smell in Production

> **If you need TRACE, you probably need spans.**

TRACE:
- local debugging
- temporary
- feature-flagged

---

## L2 — DEBUG Is Opt-In

> **If DEBUG is always on, it is not debug.**

DEBUG explains **decisions**, not flows.

---

## L3 — INFO Means "Normal and Important"

Examples:
- service started
- payment created
- job completed

---

## L4 — WARN Means "Recovered, but Notice"

Examples:
- retry
- fallback
- degraded path

---

## L5 — ERROR Means "Operation Failed"

> **If the operation failed, the span must be ERROR too.**

---

# Metrics — Golden Rules

## M0 — Metrics Judge Health

> Logs record facts.
> Traces explain behavior.
> Metrics judge health over time.

---

## M1 — Build Metrics Around SLOs

If a metric does not affect reliability decisions, rethink it.

---

## M2 — Use the Four Golden Signals

- Latency
- Traffic
- Errors
- Saturation

---

## M3 — Metrics Must Be Actionable

If you cannot act, it is noise.

Actions:
- scale
- rollback
- throttle
- investigate

---

## M4 — Avoid Cardinality Explosion

> **Never create one metric per user or request.**

---

## M5 — Alerts Come From Metrics

> Metrics trigger alerts.
> Logs and traces explain why.

---

## Final One-Line Test

> **Am I recording evidence, explaining behavior, or judging health?**

- Evidence → Log
- Behavior → Trace
- Health → Metric

---

## TL;DR

```text
Logs keep truth.
Business events keep money honest.
Traces explain behavior.
Metrics decide alerts.
Sampling is a privilege.
Assume logs will be read by lawyers.
```
