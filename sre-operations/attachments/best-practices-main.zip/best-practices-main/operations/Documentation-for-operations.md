# Golden Rules: Operational Documentation (Best Practices, Playbooks, Runbooks)

**Goal:** Every on-call engineer can find the right doc, at 3am, under stress, and act on it.
**Audience:** Engineers of all levels.

> These are rules of thumb, not laws.
> Light process. Clear actions. Start small, add only when pain repeats.

---

## Core principle (read first)

**Operational docs exist to reduce time-to-action during incidents, not to satisfy audits.**

Three types of operational docs. Each solves a different problem:

- **Best Practices** — what "good" looks like (standards, rules, expectations)
- **Playbooks** — how to run a scenario (roles, decisions, communication)
- **Runbooks** — how to do a task (exact steps, validation, rollback)

A playbook often links to several runbooks.
Best practices set the rules that playbooks and runbooks follow.

### The 10-second choice

| Ask yourself | Write a |
|---|---|
| Do we need a company standard that stays stable? | Best Practices |
| Do we need to coordinate people + decisions in a scenario? | Playbook |
| Do we need exact technical steps for a repeatable task? | Runbook |

If you can't decide, you probably need a playbook that links to runbooks.

---

## Rules

### Rule 1 — If it's not version-controlled, it doesn't exist

All operational docs live in Git, in Markdown, in the `crossmint-main` monorepo under `operations/`.

**Do**

- Store Best Practices, Playbooks, and Runbooks in `crossmint-main` under `operations/`
- Review docs in PRs like code — ownership and history are in Git
- Use Slack canvases for quick how-to references (e.g., "How do I rotate a key?") — always link back to the Git source of truth
- Use Google Drive only for collaborative or non-operational documents (post-mortems drafts, meeting notes); the canonical version must live in Git

**Do not**

- Keep the "real" version only in Slack or Google Drive
- Store runbooks in Slack threads or personal notes (they disappear)

**Rule of thumb**
> If it can't be `git blame`'d, it has no owner.

---

### Rule 2 — If it can't be used under stress, rewrite it

Docs are consumed by a tired, stressed engineer who may have joined last month.

**Write for**

- The "new joiner on-call at 3am" version of you
- Copy-paste execution (exact commands, not pseudocode)
- Skimming (headers, checklists, bold text)

**Anti-patterns**

- Walls of text without structure
- Steps that require tribal knowledge
- "See John for details"

**Rule of thumb**
> If it needs a meeting to understand, it is not operational documentation.

---

### Rule 3 — Best Practices tell people what "good" looks like, not how to type commands

A Best Practices doc defines standards and expectations. It answers: *"What is the correct way we do X?"*

**Create one when**

- The same problem happens across teams or services
- You need consistency in risky areas (deployments, secrets, access, data changes)
- You want a shared baseline for onboarding and reviews

**Target size:** 1-2 pages.

**Template**

```markdown
# Best Practices: <Topic>

## Purpose (1-2 lines)
Why this exists.

## Scope
What is included / not included.

## Rules (DO / DON'T)
- DO: ...
- DON'T: ...
```

**Anti-patterns (this is NOT Best Practices)**

- "How to restart payments-worker" → Runbook
- "What to do during a major incident" → Playbook

---

### Rule 4 — Playbooks tell people how to run the situation, not how to fix the system

A Playbook explains how to handle a scenario that needs coordination, decisions, and communication.

Google SRE frames incident response around three goals: **Coordinate, Communicate, Control**. A good playbook covers all three.

**Create one when**

- The same type of incident happens more than once
- Multiple roles are involved (engineering, support, security, leadership)
- Decisions matter (rollback vs degrade vs disable)
- Communication matters (internal updates, customer-facing status)

**Target size:** 1-2 pages + links to runbooks.

**Template**

```markdown
# Playbook: <Scenario>

## Trigger
How we know we are in this scenario (alerts, symptoms).

## Severity guide
When is it SEV-0 / SEV-1 / SEV-2?
See [Postmortems.md](../Incidents/Postmortems.md) for the full severity rubric.

## DRI (Directly Responsible Individual)
- **Incident Commander (IC):** single owner of decisions, coordination, and comms.
  At larger team sizes, the IC can delegate a dedicated Ops Lead to own mitigation so coordination does not stop.

## First 10 minutes checklist
- [ ] Declare incident + create channel
- [ ] Assign roles
- [ ] Start incident log (timeline)
- [ ] Confirm impact: users / money movement / data risk
- [ ] Choose strategy: rollback / degrade / disable

## Communication
- Internal update cadence (every 15 minutes)
- External updates: who posts, where

## Runbooks to use
- [Link 1]
- [Link 2]

## After the incident
- Postmortem owner + deadline
- Follow-ups tracked as tickets
```

> The IC is the single DRI. At current team size, one person covers IC + mitigation. Separate the roles as the team grows so coordination does not stop.

**Anti-patterns (this is NOT a Playbook)**

- "Rotate API key for provider X" → Runbook
- "Our standard for code reviews" → Best Practices

**Rule of thumb**
> A playbook without roles is a blog post.

---

### Rule 5 — Runbooks tell people exactly what to do, with validation and rollback

A Runbook is a step-by-step technical guide for one task. It must be safe to follow blindly.

**Create one when**

- An alert fires and the responder asks "what do I do now?"
- A task is repeatable and risky
- A manual fix keeps coming back
- You want to reduce dependency on one engineer

**Strong trigger:** if you did it twice manually, write a runbook.

**Target size:** 1 page max.

**Template**

```markdown
# Runbook: <Task>

## Goal
What success looks like.

## When to use
Alert name / symptom.

## Preconditions / Safety
- Required access
- Risks (money movement, data loss)
- "STOP if..." conditions

## Steps (exact)
1. ...
2. ...
3. ...

## Validation
- Metrics to check
- Logs to check
- What "good" looks like

## Rollback / Undo
Steps to revert safely.

## Escalation
Who to page, when.

## Links
Dashboards, logs, configs, related PRs.
```

**Anti-patterns (this is NOT a Runbook)**

- "How we decide severity levels" → Playbook or Best Practices
- "Our security philosophy" → Best Practices

**Rule of thumb**
> A runbook without validation steps is a guess.

---

### Rule 6 — Store docs close to what they affect

Best Practices and Playbooks live in a central operations directory.
Runbooks live near the service they affect.

**Layout**

```
crossmint-main/
  operations/
    best-practices/
      oncall.md
      deployments.md
      secrets-and-access.md
      data-changes.md
    playbooks/
      major-incident.md
      security-incident.md
      payments-provider-outage.md

services/payments/
  docs/runbooks/
    rollback.md
    disable-outgoing-transfers.md
    provider-failover.md
```

**Also link from**

- Alert descriptions (PagerDuty, Datadog) → link to the runbook
- On-call handbook → link to playbooks
- README of each service → link to its runbooks

**Rule of thumb**
> If the on-call has to search for the doc, the doc does not exist yet.

---

### Rule 7 — Every real incident must improve the docs

This is non-negotiable. Same week, same repo.

**After every SEV-0/SEV-1 incident, update at least one doc:**

- Add a missing command
- Add a new dashboard link
- Clarify a "STOP if" condition
- Create a runbook that didn't exist

**After every postmortem:**

- If the playbook was missing or wrong, fix it
- If a runbook would have prevented the incident, create it
- If Best Practices were violated, strengthen the checklist

Google SRE explicitly recommends reviewing and iterating on incident management plans and playbooks over time. We do it within the same week.

**Rule of thumb**
> Docs that don't evolve after incidents are fiction.

---

### Rule 8 — Every doc has an owner, a date, and a review cadence

A doc without an owner decays silently.

**Required metadata (footer)**

```
Owner: @team-or-person
Last updated: YYYY-MM-DD
Review: Quarterly (or after major incidents)
```

**Review cadence**

- Best Practices: quarterly
- Playbooks: quarterly or after every use
- Runbooks: after every use, or quarterly if unused (consider deleting unused runbooks)

**Rule of thumb**
> If no one owns it, no one updates it. If no one updates it, no one trusts it.

---

### Rule 9 — Prefer automation over documentation of manual pain

When a runbook becomes stable and safe, automate it.

**Progression**

1. Manual task → write a runbook
2. Stable runbook → write a script (with approvals and guardrails)
3. Stable script → automate on trigger (with observability)

**Guardrails for automation**

- Require explicit approval for destructive actions
- Log every automated execution
- Keep the runbook as documentation for the automation (what it does, when to override)

**Do not**

- Automate before the process is proven
- Automate without rollback
- Remove the runbook after automating (it becomes the automation's documentation)

**Rule of thumb**
> A runbook that runs 10 times unchanged is begging to be a script.

---

### Rule 10 — Keep docs short. Link out instead of writing novels

Operational docs are reference material, not tutorials.

**Do**

- One topic per doc
- Link to dashboards, logs, configs, related docs
- Use checklists over paragraphs
- Use exact commands over descriptions

**Do not**

- Explain architecture (that belongs in design docs)
- Duplicate content across docs (link instead)
- Write more than 2 pages for a single doc

**Rule of thumb**
> If you're scrolling, the doc is too long.

---

## Examples of when to do playbook or runbook

### Playbooks (3 docs)

1. Major Incident Playbook (SEV-0/SEV-1)
2. Payments Provider Outage Playbook
3. Security Incident Playbook (aligns with NIST incident response: detect, respond, recover)

### Runbooks

1. Rollback a deployment
2. Disable outbound transfers (safety switch)
3. Fail over payment provider
4. Rotate provider API keys / credentials
5. Restore database from backup
6. Replay a queue safely (idempotent)
7. Revoke compromised credentials
8. Scale service manually (emergency capacity)
9. Clear stuck jobs / dead-letter queue
10. Enable/disable maintenance mode

---

