# Golden Rules: Rollbacks (State, Data & Breaking Changes)

Goal: Recover production **without making things worse**.  
Audience: Engineers of all levels.

These are **rules of thumb**, not laws.  
Default to safety. Fix forward when in doubt.

---

## An Uncomfortable Truth (Read First)

### In stateful systems, “rollback” rarely means “undo”

For stateless binaries, rollback often means:
> “Deploy the previous version.”

For systems with **state** (databases, queues, caches, indexes, external side effects),
rollback can mean:

- Incompatible code reading newer data
- Data becoming invisible or unusable
- Logical corruption (broken invariants)
- Duplicated or irreversible side effects

**Rule of thumb**
> If your change touches state, rollback is a **design problem**, not an ops button.

---

## Quick Safety Checklist (Before Deploy)

Before deploying, be able to answer:

- What **state** does this change touch?
- Can the **previous version** safely run against the new state?
- Is there a **kill switch** or degradation path?
- What metric decides rollback or fix-forward?
- What is the **rollback window** (minutes vs days)?

If you cannot answer these, you are not ready to deploy.

---

## Rule 1 — Design for rollback *before* you need it

Rollback safety must be **built into the change**.

**Do**

- Assume rollback *will* happen
- Keep old and new versions compatible for a period
- Separate state changes from behavior changes
- Implement "forward-compatible" pushes for complex or problematic transitions (prepare the old code to handle the new state before the final switch).
- Ensure the previous version can still run even after the new state is applied.

**Do not**

- Deploy breaking schema changes together with new code
- Assume “we can always roll back later”

**Example**

> Adding a new column and immediately deleting the old one  
> ❌ Unsafe  
> 
> Adding a new column, keeping the old one, switching reads later  
> ✅ Rollback-safe

---

## Rule 2 — If data changes, Expand → Shadow → Contract

This pattern exists for a reason.

### Phase 1 — Expand (Schema) 

- **Action:** Add new tables or columns.

- **Constraint:** They must be nullable or have defaults.

- **Status:** Legacy code continues to run, unaware of the new additions.

### Phase 2 — Shadow Mode (Dual Writes & Backfill)

- **Dual Writes:** The application begins writing to both the old and the new schema simultaneously.

- **The "Shadow":** Reads still come from the old schema (Source of Truth). However, you perform "shadow reads" from the new schema in the background to compare results and ensure parity.

- **Backfill:** Migrate historical data using background jobs (small batches, retries, and high observability).

- **Goal:** Prove that the new schema can handle the data and the load without impacting the user.

### Phase 3 — Reverse Shadow (The Switch)

- **Primary Read:** The application switches to reading from the new schema.

- **Reverse Dual Write:** You continue writing to the old schema as a safety net. This allows for an instant rollback if things go south.

- **Verification:** Once you've operated in Reverse Shadow for a set period (hours or days) with no errors, you have successfully migrated.

### Phase 4 — Contract (Cleanup)

- **Step 1:** Code Deletion: Remove the logic that supports the dual writes and the old schema. Let the database sit "idle" but intact.

- **Step 2:** Schema Deletion: Drop the old columns/tables only when you are 100% certain no legacy code or background jobs are touching them.

**Rule of thumb**
> The “Contract” phase is where rollbacks die. Delay it.

---

## Rule 3 — Prefer fix-forward over data rollbacks

Rolling back **data** is usually worse than fixing forward.

### Why

**Code is cheap to revert:** Automated rollbacks are the fastest way to "stop the bleeding" without side effects.

**Data is expensive to undo:** Once a database state changes, "undoing" it often creates more corruption or loses new user input.

**Forward momentum:** Keeping the pipeline moving in one direction reduces configuration drift and developer confusion.

### Do

Automate rollbacks in your pipeline if health checks fail.

**Mitigate first:** If the site is down, rollback the code immediately.

**Solve second:** Once stable, ship a corrective "fix-forward" patch to address the underlying issue.

Use idempotent jobs to repair data state.

### Do not

Wait for a "hotfix" while the production environment is broken (Roll back instead).

Attempt to "undo" database migrations or data states blindly.

### Example

Deployment causes 500 errors

- ❌ Debug in production while users suffer

- ✅ Pipeline: Auto-rollback to previous stable version

- ✅ Human: Develop fix, test, and deploy forward as a new version
---

## Rule 4 — Blue/Green + databases is guilty until proven innocent

Blue/Green deployments assume:

> “Old and new versions can swap instantly.”

Databases break that assumption.

**What can go wrong**

- New code writes data
- Traffic switches back
- Old code cannot read the data
- Users believe data is lost

**Golden rule**
> If rollback can make user data disappear, do not use Blue/Green.

---

## Rule 5 — Feature OFF beats binary rollback (when state is involved)

Turning a feature **off** is often safer than reverting code. - **Provided the "OFF" state is a tested path.**

**Why**

- New code understands the new data
- You avoid backward incompatibility
- You stop the damage without rewriting history
- Safety Gap: If the "OFF" state isn't tested in the current build, you aren't "turning it off," you're "entering unknown territory."

**Do**

- Design features with real kill switches
- Allow safe degradation
- Test the "OFF" state


**Do not**

- Use flags to hide destructive migrations
- Assume a flag makes a breaking change safe
- Assume "Off" works by default: Unused code paths rot.

**Example**

> New checkout logic fails  
> ❌ Roll back code that already wrote orders  
> ✅ Disable checkout_v3 flag

---

## Rule 6 — Rollbacks get more dangerous over time

A feature that has been live for:

- Hours
- Days
- Or weeks

…is no longer safe to “undo”.

**Why**

- Data has accumulated
- External systems were called
- Invariants have shifted

**Rule of thumb**
> After a certain time, rollback becomes **migration + reconciliation**, not a deploy.

**Do**

- Define a rollback window explicitly
- Document what happens to side effects

---

## Rule 7 — Breaking changes require coexistence, not big-bang rollbacks

For incompatible changes:

**Do**

- Version contracts (APIs, events, schemas)
- Support multiple versions temporarily
- Migrate producers and consumers independently

**Do not**

- Break the contract and rely on rollback to save you

**Example**

> New event schema  
> ❌ Change producer + consumer at once  
> ✅ Support v1 and v2 during transition

---

## Rule 8 — Rollback decisions must be metric-driven

During incidents, fear is high and time is short. **The goal is to make rollbacks a safe, frequent, and non-eventful part of our pipeline.**

**Before deploy, define**

- Error rate threshold
- Latency threshold
- Saturation limits
- Auto-rollback or manual decision

**Good**

- **Safety-first mindset:** Rolling back early and often when thresholds are met.
- Automatic rollback or flag-off
- Clear alerts

**Bad**

- “We’ll decide when it happens”
- Hesitating to roll back because "we aren't 100% sure yet."

**Rule of thumb**
> If you cannot measure impact, rollback is a guess.

---

## Rule 9 — Backups are for disasters, not feature bugs

Backups and point-in-time recovery are critical —
but they are **not** a deployment rollback tool.

**Use backups for**

- Data corruption
- Accidental deletes
- Irreversible failures

**Do not**

- Restore production to fix a broken feature

---

## Rule 10 — Separate state change from behavior change

The safest deployments follow this order:

1. Make the state compatible
2. Deploy new code
3. Enable behavior
4. Remove old paths later

**Rule of thumb**
> If state and behavior change together, rollback will hurt.

---

