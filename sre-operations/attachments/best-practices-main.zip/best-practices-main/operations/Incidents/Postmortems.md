# Golden Rules: Postmortems (Incidents & Learning)

Goal: Turn incidents into **repeatable learning** without slowing engineers down.
Audience: Engineers of all levels. English-friendly (non-native).

These are **rules of thumb**, not laws.
Default to **simple + consistent**. Optimize for **follow-through**.

---

## Why this exists (Crossmint)

As we scale Crossmint, incidents are inevitable.
Chaos, repeated failures, and hero-driven fixes are not.

This initiative exists to:
- Turn incidents into clear, repeatable learning
- Reduce oncall stress and cognitive load
- Make reliability investments based on data (not anecdotes)
- Improve customer trust by responding and learning consistently

---

## Golden Rules (First Principles)

### Golden Rule #1 — If customers were hurt, we must learn
If an incident hurts customers or breaks an SLO, we must learn from it.
Postmortems are not paperwork — they are how we prevent the same failure from happening again.

### Golden Rule #2 — If we cannot extract actions, the postmortem failed
Narrative is useful, but **action items with owners and deadlines** are the real output.

### Golden Rule #3 — Learning must be easier than ignoring the problem
Heavy, slow, bureaucratic processes will be bypassed.
Simplicity is a feature, not a compromise.

### Golden Rule #4 — Optimize systems, not individual performance
Incidents reveal system weaknesses, not personal failures.
Blamelessness is required for honest learning.

---

## An uncomfortable truth (Read First)

### A postmortem that ends with "we understand what happened" is incomplete

Understanding is **diagnosis**.
A postmortem is complete only when we also have **system changes** planned and tracked.

**Rule of thumb**
> If we cannot point to concrete changes (code/config/alerts/runbooks/process),
> we did not finish the postmortem.

---

## Quick checklist (Before closing an incident)

Before we say "done", we should be able to answer:

- **Impact:** Who was affected? What broke? How long?
- **Detection:** How did we learn about it? Could we have detected earlier?
- **Mitigation:** What stopped the bleeding?
- **Cause:** What failed (system-wise)? What conditions made it possible?
- **Actions:** What will we change to reduce recurrence and/or blast radius?
- **Ownership:** Do action items exist as tickets, with owners + due dates?

If we cannot answer these, we are not done.

---

## Severity rubric (SEV-0 … SEV-4)

We need a single shared rubric. Consistency matters more than perfection.

**SEV-0 — Critical**
- Broad outage / critical functionality down
- Severe data loss/corruption risk
- High business risk, urgent exec visibility

**SEV-1 — Major**
- Major customer impact or clear SLO breach
- Large customer affected, urgent response required

**SEV-2 — High**
- Significant impact but limited scope (e.g., <10% of users, single non-critical service)
- Workaround exists or partial degradation

**SEV-3 — Moderate**
- Limited impact, small subset of customers
- Minimal degradation, low urgency

**SEV-4 — Low / Near miss**
- No customer impact (internal-only) OR near miss worth learning from

> Duration amplifies severity: a SEV-3 issue lasting >4 hours may warrant SEV-2 treatment.
> Financial transaction impact or regulatory exposure automatically escalates to SEV-1 minimum.

---

## When do we write a postmortem?

### Severity → Postmortem mapping

| Severity | Postmortem | Review meeting |
|----------|-----------|----------------|
| SEV-0    | MUST Full | Required (sync) |
| SEV-1    | MUST Full | Required (sync) |
| SEV-2    | SHOULD (Full or Lite) | Recommended (async OK) |
| SEV-3    | MAY Lite  | Not required |
| SEV-4    | MAY Lite  | Not required |

> Any incident may be escalated to a higher postmortem tier if the responders or oncall lead judge the learning value warrants it.

### MUST (Full postmortem)
Write a **Full** postmortem when any is true:

- SLO/SLA breach or user-visible downtime/degradation beyond our threshold
- Data loss or incorrect customer state (even if later repaired)
- Customer complaint with **material impact** (revenue risk, enterprise customer, or high volume of reports)
- Significant impact on a large customer that needs an explanation (internal + external)
- SEV-0 / SEV-1 incident (even if SLO impact is unclear at the start; confirm later)
- Major oncall interventions (rollback, traffic shift/reroute, emergency config, manual mitigation)

### SHOULD (Lite is OK)
Recommended when:
- No SLO breach, but real customer pain (e.g., confusing error messages causing support tickets)
- Clear systemic weakness revealed (e.g., deploy without canary, missing integration test for critical path)
- Near miss — "we got lucky" (e.g., memory leak caught before OOM in prod)
- Repeat of a known failure mode (e.g., same alert paging for the third time this quarter)

### MAY (Lite)
Optional:
- Small failures with clear learning
- Minor issues worth recording so we do not rediscover them

**Anti-friction**
- **SHOULD and MAY can be "Lite".**
- **Lite can close async** (no meeting required).

---

## Lite vs Full (keep it fast)

### Lite (10–15 min, async)
Minimum:
- Impact (1–2 lines)
- Trigger/cause (1–2 lines)
- Mitigation (1–2 lines)
- 1–3 action items (owner + due date + done condition)
- Links (Slack, dashboards, PRs)

### Full (1–3 pages, reviewed)
Includes:
- Impact + scope
- Timeline (key timestamps only)
- Root cause + contributing factors
- What went well / what went poorly / where we got lucky
- Action plan (tracked to completion)

> Lite is not "less important" — it is "right-sized". A well-written Lite with strong action items is more valuable than a delayed Full with no follow-through.

---

## Rule 1 — Blameless is required

Blameless does not mean "no accountability".
It means we assign **ownership of fixes**, not **fault**.

**Do**
- Assume good intent + best info available at the time
- Use "what / how" language
- Treat "human error" as a *symptom* (why was it easy to make?)

**Do not**
- Stop at "human error"
- Use blame language ("careless", "should have known", "X broke it")

---

## Rule 2 — Speed beats perfection

Postmortems decay fast as memory fades.

**Do**
- Draft quickly while context is fresh
- Aim to finish the postmortem write-up within **3 business days** of mitigation
  (this is a guideline, not an SLA — we will measure adoption and calibrate)
- Prefer "good enough + shipped actions" over "perfect doc later"

**Do not**
- Wait weeks (details get lost, actions die)

---

## Rule 3 — Facts first: impact → timeline → causes → actions

A good postmortem answers:
- What was the customer impact?
- How did we detect it?
- What did we do to mitigate?
- Why did it happen (system causes + contributing factors)?
- What will we change?

**Timeline guidance**
- Minimal: First signal → Declared → Mitigated → Resolved
- Use exact timestamps (not "around 11")

---

## Rule 4 — Action items are the output

Narrative is context. **Action items are the deliverable.**

### Every action item MUST have
- **Owner:** one accountable person (not "the team")
- **Priority:** P0 / P1 / P2
- **Due date:** even if approximate (we will measure completion rates and calibrate expectations)
- **Done condition:** a verifiable completion statement
- **Type:** Detect / Mitigate / Repair / Prevent

**Rule of thumb**
> If you cannot verify "done", rewrite the action item.

---

## Rule 5 — Cover the full loop: Detect / Mitigate / Repair / Prevent

To avoid "we fixed the bug but will page again", classify actions:

- **Detect:** catch it earlier (alerts, dashboards, SLOs, better signals)
- **Mitigate:** reduce time-to-recover (runbooks, automation, safe fallbacks)
- **Repair:** fix the immediate defect/config/data
- **Prevent:** stop this class of incident (guardrails, validation, design change)

**Rule of thumb**
> If we only have "Repair", we will likely repeat the incident in a different shape.

---

## Rule 6 — Keep it small-team friendly (low overhead by design)

We need consistency and structure **without slowing engineers down**.

**Do**
- Default to async writing + async review
- Timebox meetings (only for SEV-0/1 or cross-team complexity)
- Keep the doc readable in one sitting

**Do not**
- Require heavy ceremonies for every incident

---

## Rule 7 — Consistency enables learning (taxonomy + IDs)

### Postmortem ID
Use the **Linear issue ID** as the postmortem ID (example: `ENG-1234`).

### Standard taxonomy (lightweight)
Capture structured fields so we can see trends:

- **Detection method** (single-select)
  - Monitor / alert
  - Customer report
  - Internal report (manual)
  - Other

- **Primary cause** (single-select)
  - Code defect
  - Configuration issue
  - Infrastructure issue
  - Third-party dependency
  - Data layer issue
  - Unknown / other

- **Contributing factors** (multi-select)
  - Missing tests
  - Missing observability
  - Missing automation
  - Documentation gaps
  - Process/ownership gaps
  - Risky rollout / flags
  - Alerting gaps
  - Capacity planning gaps

Keep taxonomy stable. Add categories only if we will actually use them.

---

## Rule 8 — Postmortem "done" is not "all fixes shipped"

Define two finish lines:

### Postmortem Done
- Lite/Full write-up exists
- Action items exist as Linear tickets with owners + due dates
- Action items are triaged (in backlog/cycle) with real priority

### Action Plan Done
- All P0/P1 action items are completed (or explicitly deferred with rationale)

---

## Rule 9 — Follow-through beats documentation

If action items are not executed, the postmortem is just a story.

**Do**
- Review open postmortem actions weekly/biweekly (15 minutes)
- Re-prioritize explicitly when BAU is heavy
- If deferring: record why + when we revisit

---

# Final note

This process only works if it is easy.
If it feels heavy, reduce scope:
- Choose Lite instead of Full
- Choose fewer, higher-ROI action items
- Prefer guardrails and simple automation over big redesigns
